<?php
/**
 *  ... Please MODIFY this file ...
 *
 *
 *  YOUR MYSQL DATABASE DETAILS
 *
 */

define("DB_HOST", '127.0.0.1');                 // hostname
define("DB_USER", 'mrantony');                  // database username
define("DB_PASSWORD", 'aA49099073');            // database password
define("DB_NAME", 'chia-farms.com');            // database name


/**
 *  ARRAY OF ALL YOUR CRYPTOBOX PRIVATE KEYS
 *  Place values from your gourl.io signup page
 *  array("your_privatekey_for_box1", "your_privatekey_for_box2 (otional)", "etc...");
 */

$cryptobox_private_keys = array(
    '58329AASpU3dBitcoincash77BCHPRVEhQhgOBAy1PPCZRGzgH',
    '58259AA6oMPpBitcoin77BTCPRVlzMru3ycbjg8bvGGQ32t0Uc',
    '58330AAiLxc8Litecoin77LTCPRVj7zglwEOMiUgrZAOtWKOsP',
    '58331AAe0kduDash77DASHPRVeEr5Ghg7cDP0fsFtlSlUz3roe',
    '58332AAIcQuHDogecoin77DOGEPRV3YuUzcupcZXdsrz5O0R99',);


define("CRYPTOBOX_PRIVATE_KEYS", implode("^", $cryptobox_private_keys));
unset($cryptobox_private_keys);
