<?php $__env->startSection('title'); ?>
    ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8##
    Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class='main-content'>
        <!-- HEADER -->
        <div class='header'>
            <div class='container-fluid'>
                <!-- Body -->
                <div class='header-body'>
                    <div class='row align-items-end'>
                        <div class='col'>
                            <h6 class='header-pretitle'>
                                Overview
                            </h6>
                            <h1 class='header-title'>
                                Dashboard
                            </h1>
                        </div>
                        <div class='col-auto'>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class='container-fluid'>
            <div class='row'>
                <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session('success')): ?>
                    <div class='col-md-12 mb-5 mt-5 alert alert-info'>
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class='row'>
                <div class='container-fluid'>
                    <div class='row'>
                    </div>
                    <div class='row'>
                        <div class='col-12'>
                            <div class='card'>
                                <div class='card-header'>
                                    <h4 class='card-header-title'>Welcome to the Beta</h4>
                                </div>
                                <div class='card-body'>
                                    <p>Thanks for joining-up to the chia-plots.com Beta. I've been working hard these
                                        past
                                        few weeks to get this service up and running and appreciate you taking the time
                                        to
                                        register. If you have any feedback feel free to send me a message any time!</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class='row'>
                        <div class='col-12 col-lg-6 col-xl'>
                            <div class='card'>
                                <div class='card-body'>
                                    <div class='row align-items-center'>
                                        <div class='col'>
                                            <h6 class='text-uppercase text-muted mb-2'>
                                                Total plots generated
                                            </h6>
                                            <span class='h2 mb-0'><?php echo e($plotsGeneratedCount); ?></span>
                                        </div>
                                        <div class='col-auto'>
                                            <span class='h2 fe fe-dollar-sign text-muted mb-0'></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class='col-12 col-lg-6 col-xl'>
                            <div class='card'>
                                <div class='card-body'>
                                    <div class='row align-items-center'>
                                        <div class='col'>
                                            <h6 class='text-uppercase text-muted mb-2'>
                                                Total GB
                                            </h6>
                                            <span class='h2 mb-0'><?php echo e($plotsGeneratedSize); ?></span>
                                        </div>
                                        <div class='col-auto'>
                                            <span class='h2 fe fe-briefcase text-muted mb-0'></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class='col-12 col-lg-6 col-xl'>
                            <div class='card'>
                                <div class='card-body'>
                                    <div class='row align-items-center'>
                                        <div class='col'>
                                            <h6 class='text-uppercase text-muted mb-2'>
                                                Ready for Download
                                            </h6>
                                            <div class='row align-items-center no-gutters'>
                                                <div class='col-auto'>
                                                    <span class='h2 mr-2 mb-0'><?php echo e($plotsReadyForDownload); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class='col-auto'>
                                            <span class='h2 fe fe-clipboard text-muted mb-0'></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class='col-12 col-lg-6 col-xl'>
                            <div class='card'>
                                <div class='card-body'>
                                    <div class='row align-items-center'>
                                        <div class='col'>
                                            <h6 class='text-uppercase text-muted mb-2'>
                                                Average cost/plot
                                            </h6>
                                            <span class='h2 mb-0'>$<?php echo e($averageCostPlot); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class='row'>
                    </div>
                    <div class='row'>
                        <div class='col-12'>
                            <div class='card'>
                                <div class='card-header'>
                                    <h4 class='card-header-title'>You referral link is:</h4>
                                </div>
                                <div class='card-body'>
                                    <p><a href="<?php echo e(\Auth::user()->getReferralLink()); ?>"><?php echo e(\Auth::user()->getReferralLink()); ?></a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class='row'>
                    </div>
                    <div class='row'>
                        <div class='col-12 col-lg-6 col-xl'>
                            <div class='card'>
                                <div class='card-body'>
                                    <div class='row align-items-center'>
                                        <div class='col'>
                                            <h6 class='text-uppercase text-muted mb-2'>
                                                Users, registered by you link
                                            </h6>
                                            <span class='h2 mb-0'><?php echo e($referralUsersCount); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class='col-12 col-lg-6 col-xl'>
                            <div class='card'>
                                <div class='card-body'>
                                    <div class='row align-items-center'>
                                        <div class='col'>
                                            <h6 class='text-uppercase text-muted mb-2'>
                                                You referral balance
                                            </h6>
                                            <span class='h2 mb-0'>$<?php echo e(number_format($referralBalans, 2)); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\chia-farm.local\resources\views/dashboard/index.blade.php ENDPATH**/ ?>