

<?php $__env->startSection('title'); ?>
    ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8##
    Tasks overview
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    Tasks overview
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class='main-content'>
        <!-- HEADER -->
        <div class='header'>
            <div class='container-fluid'>
                <!-- Body -->
                <div class='header-body'>
                    <div class='row align-items-end'>
                        <div class='col'>
                            <h6 class='header-pretitle'>
                                Overview
                            </h6>
                            <h1 class='header-title'>
                                <?php echo $__env->yieldContent('header'); ?>
                            </h1>
                        </div>
                        <div class='col-auto'>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class='container-fluid'>
            <div class='row'>
                <?php if(session('success')): ?>
                    <div class='col-md-12 mb-5 mt-5 alert alert-info'>
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="row">
                <div class="col-12">
                    <?php if(empty($tasks)): ?>
                        <div class="alert alert-primary">
                            <h4 class="alert-heading">Nothing here</h4>
                            No tasks
                        </div>
                    <?php else: ?>
                        <?php echo e($tasks->links()); ?>

                        <div class="card">
                            <div class="table-responsive mb-0">
                                <table class="table table-sm table-nowrap card-table table-hover">
                                    <thead>
                                    <tr>
                                        <th scope="col">ID</th>
                                        <th scope="col">Queue</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Wallet name</th>
                                        <th scope="col">Host name</th>
                                        <th scope="col">Storage</th>
                                        <th scope="col" colspan="2">Issued host</th>
                                        <th scope="col">Phase</th>
                                        <th scope="col">Actions</th>
                                    </tr>
                                    </thead>
                                    <tbody class="list">
                                    <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><a href="<?php echo e(route('admin::tasks::show', ['task' => $task])); ?>"><?php echo e($task->id); ?></a></td>
                                            <td><?php echo e($task->queue_id); ?></td>
                                            <td>
                                                <?php if($task->phase_status_id === App\Models\PhaseStatus::MOVED): ?>
                                                    <a href="<?php echo e($task->link); ?>">Ready</a>
                                                <?php else: ?>
                                                    <?php if($task->is_closed): ?>
                                                        Closed
                                                    <?php else: ?>
                                                        Opened
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($task->wallet->name); ?></td>
                                            <td><?php echo e($task->storage->host->name); ?></td>
                                            <td><?php echo e($task->storage->path); ?></td>
                                            <td><?php if($task->issued_host): ?> <?php echo e($task->issued_host->name); ?> <?php endif; ?></td>
                                            <td><?php if($task->issued_host): ?> <?php echo e($task->issued_at); ?> <?php endif; ?></td>
                                            <td><?php echo e($task->phase_status_id); ?>/4</td>
                                            <td>
                                                <button class="ml-1 btn btn-sm btn-outline-danger btn-delete-tasks" type="button"
                                                        data-target="#tr-<?php echo e($task['wallet_id']); ?>-<?php echo e($task['storage_id']); ?>-<?php echo e($task['queue_id']); ?>" aria-expanded="false">
                                                        <i class="fe fe-trash"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    <?php endif; ?>
                    <a class="ml-1 btn btn-sm btn-outline-info" href="<?php echo e(route('admin::tasks::create')); ?>">
                        <i class="fe fe-building"></i> Add Task
                    </a>
                </div>
            </div>
        </div>
    </div>
    <script src="/js/admin/tasks.js"></script>
    <?php echo csrf_field(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\chia-farm.local\resources\views/admin/task/index.blade.php ENDPATH**/ ?>