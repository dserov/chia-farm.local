

<?php $__env->startSection('title'); ?>
    ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8##
    Order pay
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    Order pay
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class='main-content'>
        <!-- HEADER -->
        <div class='header'>
            <div class='container-fluid'>
                <!-- Body -->
                <div class='header-body'>
                    <div class='row align-items-end'>
                        <div class='col'>
                            <h6 class='header-pretitle'>
                                Overview
                            </h6>
                            <h1 class='header-title'>
                                <?php echo $__env->yieldContent('header'); ?>
                            </h1>
                        </div>
                        <div class='col-auto'>
                            $<?php echo e(number_format($order->price * $order->plot_amount, 2)); ?> - $<?php echo e(number_format(\Auth::user()->balans, 2)); ?> = $<?php echo e(number_format($order->price * $order->plot_amount - \Auth::user()->balans, 2)); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class='container-fluid'>
            <div class='row'>
                <?php if(session('success')): ?>
                    <div class='col-md-12 mb-5 mt-5 alert alert-info'>
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div class='col-md-12 mb-5 mt-5 alert alert-warning'>
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <iframe id="iframe_payment" src="/cryptobox_payment.php?order_id=<?php echo e($order->id); ?>" frameborder="0" style="height: 1200px"></iframe>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        document.getElementById('iframe_payment').onload = function () {
            setTimeout(iResize, 350);
            // Safari and Opera need a kick-start.
            // let iSource = document.getElementById('iframe_payment').src;
            // document.getElementById('iframe_payment').src = '';
            // document.getElementById('iframe_payment').src = iSource;
        };

        function iResize() {
            document.getElementById('iframe_payment').style.height = '1200px';
            document.getElementById('iframe_payment').contentWindow.document.body.style.backgroundColor = 'transparent';
                // document.getElementById('iframe_payment').contentWindow.document.body.offsetHeight + 'px';
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\chia-farm.local\resources\views/orders/pay.blade.php ENDPATH**/ ?>