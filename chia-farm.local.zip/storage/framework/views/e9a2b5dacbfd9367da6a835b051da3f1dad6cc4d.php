

<?php $__env->startSection('title'); ?>
    ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8##
    Auctions overview
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    Auctions overview
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class='main-content'>
        <!-- HEADER -->
        <div class='header'>
            <div class='container-fluid'>
                <!-- Body -->
                <div class='header-body'>
                    <div class='row align-items-end'>
                        <div class='col'>
                            <h6 class='header-pretitle'>
                                Overview
                            </h6>
                            <h1 class='header-title'>
                                <?php echo $__env->yieldContent('header'); ?>
                            </h1>
                        </div>
                        <div class='col-auto'>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class='container-fluid'>
            <div class='row'>
                <?php if(session('success')): ?>
                    <div class='col-md-12 mb-5 mt-5 alert alert-info'>
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div class='col-md-12 mb-5 mt-5 alert alert-info'>
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="row">
                <div class="col-12">
                    <?php if($auctions->isEmpty()): ?>
                        <div class="alert alert-primary">
                            <h4 class="alert-heading">Nothing here</h4>
                            No auctions
                        </div>
                    <?php else: ?>
                        <?php echo e($auctions->links()); ?>

                        <div class="card">
                            <div class="table-responsive mb-0">
                                <table class="table table-sm table-nowrap card-table table-hover">
                                    <thead>
                                    <tr>
                                        <th scope="col">ID</th>
                                        <th scope="col">Price</th>
                                        <th scope="col">&nbsp;</th>
                                    </tr>
                                    </thead>
                                    <tbody class="list">
                                    <?php $__currentLoopData = $auctions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $auction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($auction->id); ?></td>
                                            <td><?php echo e($auction->price); ?></td>
                                            <td>
                                                <a class="ml-1 btn btn-sm btn-outline-info" href="<?php echo e(route('admin::auctions::update', ['auction' => $auction])); ?>">
                                                    <i class="fe fe-edit"></i>
                                                </a>
                                                <a class="ml-1 btn btn-sm btn-outline-danger" rel="nofollow" href="#" onclick="event.preventDefault();
                                                if (confirm('Are you sure you want to delete auction #<?php echo e($auction->id); ?>?')) { document.getElementById('delete-auction-<?php echo e($auction->id); ?>').submit(); }">
                                                    <i class="fe fe-trash"></i>
                                                </a>
                                                <form id="delete-auction-<?php echo e($auction->id); ?>" action="<?php echo e(route('admin::auctions::delete', [$auction])); ?>" method="POST" class="d-none">
                                                    <?php echo csrf_field(); ?>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    <?php endif; ?>
                    <a class="ml-1 btn btn-sm btn-outline-info" href="<?php echo e(route('admin::auctions::create')); ?>">
                        <i class="fe fe-building"></i> Add auction
                    </a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\chia-farm.local\resources\views/admin/auction/index.blade.php ENDPATH**/ ?>