

<?php $__env->startSection('title'); ?>
    ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8##
    New Wallet
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <?php if(request()->is('*/create')): ?>
        New plot
    <?php else: ?>
        Edit plot
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <!-- HEADER -->
        <div class="header">
            <div class="container-fluid">
                <!-- Body -->
                <div class="header-body">
                    <div class="row align-items-end">
                        <div class="col">
                            <h6 class="header-pretitle">
                                Overview
                            </h6>
                            <h1 class="header-title">
                                <?php echo $__env->yieldContent('header'); ?>
                            </h1>
                        </div>
                        <div class="col-auto">
                            <a class="btn btn-primary" href="<?php echo e(route('dashboard')); ?>">Back to dashboard</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <?php if( session('error')): ?>
                    <div class="col-md-12 alert alert-warning" role="alert">
                        <strong><?php echo e(session('error')); ?></strong>
                    </div>
                <?php endif; ?>
            </div>
            <div class="row">
                <div class="card col-md-12 mt-5">
                    <div class="card-body">
                        <form class="simple_form new_plot" id="new_plot" novalidate="novalidate"
                              action="<?php echo e(route('plots::save')); ?>" accept-charset="UTF-8" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group select optional wallet_id">
                                <label class="select optional" for="wallet_id">Wallet</label>
                                <select class="form-control select optional <?php $__errorArgs = ['wallet_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="wallet_id" id="wallet_id">
                                    <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($wallet->id); ?>" label="<?php echo e($wallet->name); ?>"><?php echo e($wallet->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['wallet_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <small class="form-text text-muted">Select wallet</small>
                            </div>
                            <div class="form-group string required wallet_master_key">
                                <label class="string required" for="wallet_master_key">Master key <abbr title="required">*</abbr></label>
                                <input class="form-control string required <?php $__errorArgs = ['wallet.master_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="wallet[master_key]"
                                        id="wallet_master_key" value="<?php echo e(old('wallet.master_key')); ?>">
                                <small class="form-text text-muted">Please ensure you are using the *master key* mixing
                                    the keys up will make the plots invalid.
                                </small>
                                <?php $__errorArgs = ['wallet.master_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group string required wallet_farmer_key">
                                <label class="string required" for="wallet_farmer_key">Farmer key <abbr title="required">*</abbr></label>
                                <input class="form-control string required <?php $__errorArgs = ['wallet.farmer_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="wallet[farmer_key]"
                                        id="wallet_farmer_key" value="<?php echo e(old('wallet.farmer_key')); ?>">
                                <small class="form-text text-muted">Please ensure you are using the *farmer key* mixing
                                    the keys up will make the plots invalid.
                                </small>
                                <?php $__errorArgs = ['wallet.farmer_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group string required wallet_pool_key">
                                <label class="string required" for="wallet_pool_key">Pool key<abbr title="required">*</abbr></label>
                                <input class="form-control string required <?php $__errorArgs = ['wallet.pool_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="wallet[pool_key]"
                                       id="wallet_pool_key" value="<?php echo e(old('wallet.pool_key')); ?>">
                                <?php $__errorArgs = ['wallet.pool_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <script>
                                // Define function so that we can call it again later if we need to reset it
                                // This executes reCAPTCHA and then calls our callback.
                                // function executeRecaptchaForNewOrder() {
                                //     grecaptcha.ready(function () {
                                //         grecaptcha.execute('6LcDaL4aAAAAAEpzv1Zrjq94R_awI_a2QEl-shn4', {action: 'new_order'}).then(function (token) {
                                //             setInputWithRecaptchaResponseTokenForNewOrder('g-recaptcha-response-data-new-order', token)
                                //         });
                                //     });
                                // };
                                // Invoke immediately
                                // executeRecaptchaForNewOrder()

                                // Async variant so you can await this function from another async function (no need for
                                // an explicit callback function then!)
                                // Returns a Promise that resolves with the response token.
                                async function executeRecaptchaForNewOrderAsync() {
                                    return new Promise((resolve, reject) => {
                                        grecaptcha.ready(async function () {
                                            resolve(await grecaptcha.execute('6LcDaL4aAAAAAEpzv1Zrjq94R_awI_a2QEl-shn4', {action: 'new_order'}))
                                        });
                                    })
                                };

                                var setInputWithRecaptchaResponseTokenForNewOrder = function (id, token) {
                                    var element = document.getElementById(id);
                                    element.value = token;
                                }

                            </script>
                            <input type="hidden" name="g-recaptcha-response-data[new_order]"
                                   id="g-recaptcha-response-data-new-order"
                                   data-sitekey="6LcDaL4aAAAAAEpzv1Zrjq94R_awI_a2QEl-shn4"
                                   class="g-recaptcha g-recaptcha-response "
                                   value="03AGdBq26uE4fgkgT10mFBmiU2yIJpJ6zOOWRijXF8ULNETPpXcCVpxxC7LlsEdoeHeXDocYdeNoy0NUhWl9zVGsqN2EAN2n6WUnAqdgx7At2_D7gSypbq8Fcht7Q0wUzvZmrP_XvtRbAohBE0Tx6kFeT2lS_IL0xqsJo2u9XiXX544rgqqrqnMBjzY243TC4b0W-CCa0kMf3buj3-aOJ9bFIBueGoE4P6lkSW6QQEJWih0qnN5HR3R9mXoYHNLvvT2gVJSZ3HWm7V8sbdz9TxjQsv-k2Bf66IZp_8NU1tvHHyU13XLjh31ZYF20X1qGjxZbzYv0OudHldJ-RqJlyiuwRiikiesBhdi4lH_HRFgRziZYJ4gxUWCl-h0aOozOOXcHI3MAzsga8kgFEkyoqK077TGGxkIlW7iHPS8STtJv2k8A1RkYFq_RE5G0sxH6BALYXvOLX31YsWzkVYQdgYJHfCMjQQOO_WHA"
                                   style="">

                            <input type="submit" name="commit" value="Save" class="btn btn-primary"
                                   data-disable-with="Saving...">
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\chia-farm.local\resources\views/plots/new.blade.php ENDPATH**/ ?>