

<?php if(session('status')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session('status')); ?>

    </div>
<?php endif; ?>
<?php $__env->startSection('title'); ?>
    ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8##
    Hosts overview
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    Hosts overview
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class='main-content'>
        <!-- HEADER -->
        <div class='header'>
            <div class='container-fluid'>
                <!-- Body -->
                <div class='header-body'>
                    <div class='row align-items-end'>
                        <div class='col'>
                            <h6 class='header-pretitle'>
                                Overview
                            </h6>
                            <h1 class='header-title'>
                                <?php echo $__env->yieldContent('header'); ?>
                            </h1>
                        </div>
                        <div class='col-auto'>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class='container-fluid'>
            <div class='row'>
                <?php if(session('success')): ?>
                    <div class='col-md-12 mb-5 mt-5 alert alert-info'>
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="row">
                <div class="col-12">
                    <?php if($hosts->isEmpty()): ?>
                        <div class="alert alert-primary">
                            <h4 class="alert-heading">Nothing here</h4>
                            No hosts
                        </div>
                    <?php else: ?>
                        <?php echo e($hosts->links()); ?>

                        <div class="card">
                            <div class="table-responsive mb-0">
                                <table class="table table-sm table-nowrap card-table table-hover">
                                    <thead>
                                    <tr>
                                        <th scope="col">Name</th>
                                        <th scope="col">Ip</th>
                                        <th scope="col">Type</th>
                                        <th scope="col">Max plots</th>
                                    </tr>
                                    <tr>
                                        <th scope="col">&nbsp;</th>
                                        <th scope="col">Tmp Free</th>
                                        <th scope="col">Plot Free</th>
                                        <th scope="col">Storage Free</th>
                                    </tr>
                                    </thead>
                                    <tbody class="list">
                                    <?php $__currentLoopData = $hosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $host): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($host->name); ?></td>
                                            <td><?php echo e($host->ip); ?></td>
                                            <td><?php echo e($host->type); ?></td>
                                            <td><?php echo e($host->plots_count); ?></td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <a class="ml-1 btn btn-sm btn-outline-info" href="<?php echo e(route('admin::hosts::update', [ 'host' => $host])); ?>">
                                                    <i class="fe fe-edit"></i>
                                                </a>
                                                <a class="ml-1 btn btn-sm btn-outline-danger" rel="nofollow" href="#" onclick="event.preventDefault();
                                                if (confirm('Are you sure you want to delete host #<?php echo e($host->name); ?>?')) { document.getElementById('delete-host-<?php echo e($host->id); ?>').submit(); }">
                                                    <i class="fe fe-trash"></i>
                                                </a>
                                                <form id="delete-host-<?php echo e($host->id); ?>" action="<?php echo e(route('admin::hosts::delete', [ 'host' => $host])); ?>" method="POST" class="d-none">
                                                    <?php echo csrf_field(); ?>
                                                </form>
                                                <a class="ml-1 btn btn-sm btn-outline-info btn-show-storages" href="#">
                                                    <i class="fe fe-building"></i>
                                                </a>
                                                <div class="storages-container p-3 btn-sm">
                                                    <?php $__currentLoopData = $host->storages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $storage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <span><?php echo e($storage->path); ?></span>:&nbsp;&nbsp;<span><?php echo e(\App\Helpers\HumanReadable::formatBytes($storage->free_size * 1024 * 1024 * 1024)); ?></span>
                                                        <br>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </td>
                                            <td><?php echo e(\App\Helpers\HumanReadable::formatBytes($host->tmp_free * 1024 * 1024 * 1024)); ?></td>
                                            <td><?php echo e(\App\Helpers\HumanReadable::formatBytes($host->plot_free * 1024 * 1024 * 1024)); ?></td>
                                            <td><?php echo e(\App\Helpers\HumanReadable::formatBytes($host->storages->sum('free_size') * 1024 * 1024 * 1024)); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    <?php endif; ?>
                    <a class="ml-1 btn btn-sm btn-outline-info" href="<?php echo e(route('admin::hosts::create')); ?>">
                        <i class="fe fe-building"></i> Add host
                    </a>
                </div>
            </div>
        </div>
    </div>
    <style>
        .btn-show-storages:hover + .storages-container {
            display: block;
        }
        .storages-container:hover {
            display: block;
        }
        .storages-container {
            display: none;
            width: 150px;
            position: absolute;
            background-color: #0a1421;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\chia-farm.local\resources\views/admin/host/index.blade.php ENDPATH**/ ?>