

<?php $__env->startSection("content"); ?>
    <div class="pt-7 pb-8 bg-dark bg-ellipses">
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-md-10 col-lg-8 col-xl-6">
                    <h1 class="display-3 text-center text-white">
                        Speedtest
                    </h1>
                    <p class="lead text-center text-muted">It's important that, once your Chia plots are bought and generated, you can download them in a timely matter. Please do the speedtest so you can see how long your downloads will take.</p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <p id="speedtest-progress">Waiting to start</p>
                    </div>
                    <div class="card-footer">
                        <select class="custom-select" id="dc">
                            <?php $__currentLoopData = $download_servers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <a class="btn btn-success mt-2" id="start-speedtest-button" href="#">Start test</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\chia-farm.local\resources\views/speedtest/index.blade.php ENDPATH**/ ?>