<?php echo e($slot); ?>

<?php /**PATH D:\OpenServer\domains\chia-farm.local\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>