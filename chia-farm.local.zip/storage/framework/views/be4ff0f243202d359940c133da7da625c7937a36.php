<?php $__env->startSection('content'); ?>
    <h1 class='display-4 text-center mb-3'>Log in</h1>
    <form class="simple_form new_user" id="new_user" novalidate="novalidate" action="<?php echo e(route('login')); ?>"
          accept-charset="UTF-8" method="post">
        <?php echo csrf_field(); ?>
        <div class='form-inputs'>
            <div class="form-group email optional user_email">
                <label class="email optional"
                       for="user_email">Email</label>
                <input class="form-control string email optional <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       autocomplete="email" autofocus="autofocus"
                       type="email" value="<?php echo e(old('email')); ?>" name="email" id="user_email"/>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group password optional user_password">
                <label class="password optional"
                       for="user_password">Password</label>
                <input
                        class="form-control password optional <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        autocomplete="current-password" type="password"
                        name="password" id="user_password"/>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <fieldset class="form-group boolean optional user_remember_me">
                <div class="form-check">
                    <input name="remember" type="hidden" value="0"/>
                    <input class="form-check-input boolean optional" type="checkbox" value="1" name="remember"
                           id="user_remember" <?php echo e(old('remember') ? 'checked' : ''); ?>/>
                    <label class="form-check-label boolean optional"
                           for="user_remember">Remember me</label>
                </div>
            </fieldset>
        </div>
        <div class='form-actions'>
            <input type="submit" name="commit" value="Log in" class="btn btn btn-primary" data-disable-with="Log in"/>
        </div>
    </form><a href="<?php echo e(route('register')); ?>">Sign up</a>
    <br>
    <?php if(Route::has('password.request')): ?>
        <a href="<?php echo e(route('password.request')); ?>">
            <?php echo e(__('Forgot your password?')); ?>

        </a>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\chia-farm.local\resources\views/auth/login.blade.php ENDPATH**/ ?>