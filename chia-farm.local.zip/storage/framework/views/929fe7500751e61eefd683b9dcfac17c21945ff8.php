<?php $__env->startSection('content'); ?>
    <h2>Forgot your password?</h2>
    <?php if(session('status')): ?>
        <div class="col-md-12 mb-5 mt-5 alert alert-info">
            <?php echo e(session('status')); ?>

            You will receive an email with instructions on how to reset your password in a few minutes.
        </div>
    <?php endif; ?>
    <form class="simple_form new_user" id="new_user" novalidate="novalidate" action="<?php echo e(route('password.email')); ?>"
          accept-charset="UTF-8" method="post">
        <?php echo csrf_field(); ?>
        <div class='form-inputs'>
            <div class="form-group email required user_email">
                <label class="email required" for="user_email">Email <abbr
                            title="required">*</abbr></label>
                <input class="form-control string email required <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       autocomplete="email" autofocus="autofocus"
                       required="required" aria-required="true"
                       type="email" value="<?php echo e(old('email')); ?>" name="email"
                       id="user_email"/>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class='form-actions'>
            <input type="submit" name="commit" value="Send me reset password instructions" class="btn btn btn-primary"
                   data-disable-with="Send me reset password instructions"/>
        </div>
    </form><a href="<?php echo e(route('login')); ?>">Log in</a>
    <br>
    <a href="<?php echo e(route('register')); ?>">Sign up</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\chia-farm.local\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>