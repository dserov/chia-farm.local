<!DOCTYPE html>
<html>
<head>
    <meta content='text/html; charset=UTF-8' http-equiv='Content-Type'>
    <title><?php $__env->startSection("title"); ?> Buy Chia Plots, fast turnaround time and easy downloads <?php echo $__env->yieldSection(); ?></title>
    <meta content='width=device-width,initial-scale=1' name='viewport'>
    <meta content='Buy Chia plots with a few clicks without any technical knowledge, completely self-serviced and with a 24 hour turnaround time.
' name='description'>
    <meta name="csrf-param" content="authenticity_token"/>
    <meta name="csrf-token" content="HaGvmlhC_bb44jKFuWEBXfmxaq3lYgNrhAZXHO_b0j5_S5Q4X6mcb4jAIiXtxEpbPqT_8xrhoJVg5-CZYjh5OA"/>
    <link rel="stylesheet" media="all" href="/assets/application-12a9f60b4a6c861ac6d006963ae1d290ca71aa1f0d6b757d5333b92a6827c68c.css" data-turbolinks-track="reload"/>
    <script src="/packs/js/application-f82b56a7c4b6401d21fb.js" data-turbolinks-track="reload"></script>
    <script src="/packs/js/speedtest-3fbf7e70a343d92fec1a.js" data-turbolinks-track="reload"></script>
    <script async='' data-domain='chia-plots.com' defer='defer' src='https://plausible.io/js/plausible.js'></script>
</head>
<body class='border-top border-top-2 border-primary'>
<?php echo $__env->make("blocks.menu", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class='container'>
    <div class='row'>
        <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
    <div class='row justify-content-center'>
        <div class='col-12'>
            <?php echo $__env->yieldContent("content"); ?>
        </div>
    </div>
</div>

    
        
    
    
        
            
                
            
            
                
        
    


</body>
</html>
<?php /**PATH D:\OpenServer\domains\chia-farm.local\resources\views/layouts/main.blade.php ENDPATH**/ ?>