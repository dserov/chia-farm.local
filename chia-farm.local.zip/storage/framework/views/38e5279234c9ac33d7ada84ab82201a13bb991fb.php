<?php if(session('status')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session('status')); ?>

    </div>
<?php endif; ?>
<?php $__env->startSection('title'); ?>
    ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8##
    Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <!-- HEADER -->
        <div class="header">
            <div class="container-fluid">
                <!-- Body -->
                <div class="header-body">
                    <div class="row align-items-end">
                        <div class="col">
                            <h6 class="header-pretitle">
                                Overview
                            </h6>
                            <h1 class="header-title">
                                Ready to Download
                            </h1>
                        </div>
                        <div class="col-auto">
                            <a class="btn btn-primary" href="<?php echo e(route('plots::text')); ?>">Download links as text</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <?php if(session('success')): ?>
                    <div class='col-md-12 mb-5 mt-5 alert alert-info'>
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="row">
                <div class="col-12">
                    <?php if(empty($tasks)): ?>
                        <div class="alert alert-primary">
                            <h4 class="alert-heading">Too bad...</h4>
                            Nothing is ready yet, check back later.
                        </div>
                    <?php else: ?>
                        <table class="table table-sm table-nowrap card-table table-hover">
                            <thead>
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col">Link</th>
                            </tr>
                            </thead>
                            <tbody class="list">
                                <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($task->id); ?></td>
                                        <td>
                                            <a href="<?php echo e($task->link); ?>">Download</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\chia-farm.local\resources\views/plots/index.blade.php ENDPATH**/ ?>