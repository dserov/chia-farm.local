<!DOCTYPE html>
<html>
<head>
    <meta content='text/html; charset=UTF-8' http-equiv='Content-Type'>
    <title>
        <?php $__env->startSection('title'); ?>Chia Plots - <?php echo $__env->yieldSection(); ?>
    </title>
    <meta content='width=device-width,initial-scale=1' name='viewport'>
    <link rel="stylesheet" media="all"
          href="/assets/application-12a9f60b4a6c861ac6d006963ae1d290ca71aa1f0d6b757d5333b92a6827c68c.css"
          data-turbolinks-track="reload"/>
    <script src="/packs/js/application-f82b56a7c4b6401d21fb.js" data-turbolinks-track="reload"></script>
    <?php $__env->startSection('header-scripts'); ?> <?php echo $__env->yieldSection(); ?>
</head>
<body>
<?php echo $__env->make('blocks.dashboard.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>
</body>
</html>
<?php /**PATH D:\OpenServer\domains\chia-farm.local\resources\views/layouts/dashboard.blade.php ENDPATH**/ ?>