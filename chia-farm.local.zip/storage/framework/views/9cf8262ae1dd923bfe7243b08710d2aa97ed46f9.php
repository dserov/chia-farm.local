

<?php $__env->startSection('title'); ?>
    ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8##
    Task view
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    Task view
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class='main-content'>
        <!-- HEADER -->
        <div class='header'>
            <div class='container-fluid'>
                <!-- Body -->
                <div class='header-body'>
                    <div class='row align-items-end'>
                        <div class='col'>
                            <h6 class='header-pretitle'>
                                Overview
                            </h6>
                            <h1 class='header-title'>
                                <?php echo $__env->yieldContent('header'); ?>
                            </h1>
                        </div>
                        <div class='col-auto'>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class='container-fluid'>
            <div class='row'>
                <?php if(session('success')): ?>
                    <div class='col-md-12 mb-5 mt-5 alert alert-info'>
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="row">
                <div class="card col-md-12 mt-5">
                    <div class="card-body">
                        <div class="form-group string required task_id">
                            <label class="string required" for="task_id">ID</label>
                            <input class="form-control string required" name="task_id" id="task_id" value="<?php echo e($task->id); ?>">
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="form-group string required queue_id">
                            <label class="string required" for="queue_id">Queue ID</label>
                            <input class="form-control string required" name="queue_id" id="queue_id" value="<?php echo e($task->queue_id); ?>">
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="form-group string required is_closed">
                            <label class="string required" for="is_closed">Status</label>
                            <?php if($task->phase_status_id === App\Models\PhaseStatus::MOVED): ?>
                                <br><a class="form-control string required" href="<?php echo e($task->link); ?>">Ready</a>
                            <?php else: ?>
                                <input class="form-control string required" name="is_closed" id="is_closed" value="<?php if($task->is_closed): ?>Closed <?php else: ?> Opened <?php endif; ?>">
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="form-group string required wallet_name">
                            <label class="string required" for="wallet_name">Wallet name</label>
                            <input class="form-control string required" name="wallet_name" id="wallet_name" value="<?php echo e($task->wallet->name); ?>">
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="form-group string required host_name">
                            <label class="string required" for="host_name">Host name</label>
                            <input class="form-control string required" name="host_name" id="host_name" value="<?php echo e($task->storage->host->name); ?>">
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="form-group string required storage_path">
                            <label class="string required" for="storage_path">Storage</label>
                            <input class="form-control string required" name="storage_path" id="storage_path" value="<?php echo e($task->storage->path); ?>">
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="form-group string required issued_host_name">
                            <label class="string required" for="issued_host_name">Issued host</label>
                            <input class="form-control string required" name="issued_host_name" id="issued_host_name" value="<?php if($task->issued_host): ?> <?php echo e($task->issued_host->name); ?> <?php endif; ?>">
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="form-group string required issued_at">
                            <label class="string required" for="issued_at">Issued at</label>
                            <input class="form-control string required" name="issued_at" id="issued_at" value="<?php if($task->issued_host): ?> <?php echo e($task->issued_at); ?> <?php endif; ?>">
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="form-group string required phase_status_id">
                            <label class="string required" for="phase_status_id">Phase</label>
                            <input class="form-control string required" name="phase_status_id" id="phase_status_id" value="<?php echo e($task->phase_status_id); ?>/4">
                        </div>
                    </div>
                    <?php if($task->last_error): ?>
                        <div class="card-body">
                            <div class="form-group string required last_error">
                                <label class="string required" for="last_error">Last Error</label>
                                <input class="form-control string required is-invalid" name="last_error" id="last_error" value="<?php echo e($task->last_error); ?>">
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\chia-farm.local\resources\views/admin/task/show.blade.php ENDPATH**/ ?>