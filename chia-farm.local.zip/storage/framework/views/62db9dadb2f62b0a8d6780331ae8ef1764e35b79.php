

<?php if(session('status')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session('status')); ?>

    </div>
<?php endif; ?>
<?php $__env->startSection('title'); ?>
    ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8##
    Wallet overview
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    Wallet overview
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class='main-content'>
        <!-- HEADER -->
        <div class='header'>
            <div class='container-fluid'>
                <!-- Body -->
                <div class='header-body'>
                    <div class='row align-items-end'>
                        <div class='col'>
                            <h6 class='header-pretitle'>
                                Overview
                            </h6>
                            <h1 class='header-title'>
                                <?php echo $__env->yieldContent('header'); ?>
                            </h1>
                        </div>
                        <div class='col-auto'>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class='container-fluid'>
            <div class='row'>
                <div class="col-12">
                    <?php if(session('success')): ?>
                        <div class="col-md-12 alert alert-info" role="alert">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if( session('error')): ?>
                        <div class="col-md-12 alert alert-warning" role="alert">
                            <strong><?php echo e(session('error')); ?></strong>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <a href="<?php echo e(route('wallet::create')); ?>" class="btn btn-outline-secondary mb-4">Add new wallet</a>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <?php if(!$wallets->isEmpty()): ?>
                        <div class="card">
                            <div class="table-responsive mb-0">
                                <table class="table table-sm table-nowrap card-table table-hover">
                                    <thead>
                                    <tr>
                                        <th class="d-none d-md-table-cell">ID</th>
                                        <th>Name</th>
                                        <th>Actions</th>
                                    </tr>
                                    </thead>
                                    <tbody class="list">
                                    <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th class="d-none d-md-table-cell" scope="row">Wallet #<?php echo e($wallet->id); ?></th>
                                            <td><?php echo e($wallet->name); ?></td>
                                            <td>
                                                <a class="ml-1 btn btn-sm btn-outline-success" href="<?php echo e(route('wallet::update', [$wallet])); ?>">
                                                    <i class="fe fe-money"></i> Edit wallet</a>
                                                <a class="ml-1 btn btn-sm btn-outline-danger" rel="nofollow"
                                                   href="#"
                                                   onclick="event.preventDefault();
                                                   if (confirm('Are you sure you want to delete wallet #<?php echo e($wallet->name); ?>?')) { document.getElementById('delete-wallet-<?php echo e($wallet->id); ?>').submit(); }">
                                                    <i class="fe fe-trash"></i>
                                                    Delete wallet
                                                </a>
                                                <form id="delete-wallet-<?php echo e($wallet->id); ?>" action="<?php echo e(route('wallet::delete', [$wallet])); ?>" method="POST" class="d-none">
                                                    <?php echo csrf_field(); ?>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\chia-farm.local\resources\views/wallet/index.blade.php ENDPATH**/ ?>