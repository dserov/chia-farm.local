

<?php if(session('status')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session('status')); ?>

    </div>
<?php endif; ?>
<?php $__env->startSection('title'); ?>
    ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8##
    New Order
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    New Order
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <!-- HEADER -->
        <div class="header">
            <div class="container-fluid">
                <!-- Body -->
                <div class="header-body">
                    <div class="row align-items-end">
                        <div class="col">
                            <h6 class="header-pretitle">
                                Overview
                            </h6>
                            <h1 class="header-title">
                                Plots for order #<?php echo e($order->id); ?>


                            </h1>
                        </div>
                        <div class="col-auto">
                            <a class="btn btn-primary" href="<?php echo e(route('orders::index')); ?>">Back to orders</a>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
            </div>
            <div class="row">
                <div class="col-md-6 col-sm-12 col-xl-4">
                    <div class="card">
                        <div class="card-body">
                            <div class="row align-items-center">
                                <div class="col">
                                    <!-- Title -->
                                    <h6 class="text-uppercase text-muted mb-2">
                                        Order price
                                    </h6>
                                    <!-- Heading -->
                                    <span class="h2 mb-0">
                                    $<?php echo e(number_format($order->price * $order->plot_amount, 2)); ?>

                                    </span>
                                </div>
                                <div class="col-auto">
                                    <?php if(
                                        $order->status_id != \App\Models\Status::PAYED &&
                                        $order->status_id != \App\Models\Status::PLOT_READY &&
                                        $order->status_id != \App\Models\Status::PLOT_QUEUED
                                    ): ?>
                                        <a class="ml-1 btn btn-sm btn-outline-success" data-confirm="Refunds are not possible are you sure you want to continue paying?"
                                           href="<?php echo e(route('orders::pay', [$order])); ?>">
                                            <i class="fe fe-money"></i> Pay with Crypto</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-sm-12 col-xl-2">
                    <div class="card">
                        <div class="card-body">
                            <div class="row align-items-center">
                                <div class="col">
                                    <!-- Title -->
                                    <h6 class="text-uppercase text-muted mb-2">
                                        Plots completed
                                    </h6>
                                    <!-- Heading -->
                                    <span class="h2 mb-0">
                                        <?php echo e($order->plot_completed); ?>/<?php echo e($order->plot_amount); ?>

                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="card">
                        <div class="table table-responsive-sm">
                            <table class="table table-sm table-nowrap card-table">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Status</th>
                                    <th>Plot Phase</th>
                                    <th>
                                        <span class="float-right">Actions</span>
                                    </th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row">Plot #<?php echo e($task->id); ?></th>
                                        <td>
                                            <div class="badge badge-soft-warning">
                                                <?php if($task->phase_status_id == \App\Models\PhaseStatus::MOVED): ?>
                                                    Completed
                                                <?php else: ?>
                                                    <?php if($task->issued_host_id == 0): ?>
                                                        Waiting in queue
                                                    <?php else: ?>
                                                        In progress
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td>
                                            <?php if($task->phase_status_id == \App\Models\PhaseStatus::MOVED): ?>
                                                4/4
                                            <?php else: ?>
                                                <?php echo e($task->phase_status_id ?? 0); ?>/4
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="float-right">
                                                <?php if($task->phase_status_id == \App\Models\PhaseStatus::MOVED): ?>
                                                    <a href="<?php echo e($task->link); ?>">Download</a>
                                                <?php endif; ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-sm-12 col-lg-12 col-xxl-4">
                    <div class="card">
                        <div class="card-body">
                            <div class="list-group list-group-flush my-n3">
                                <div class="list-group-item">
                                    <div class="row align-items-center">
                                        <div class="col">
                                            <h5 class="mb-0">
                                                Order created at
                                            </h5>
                                        </div>
                                        <div class="col-auto">
                                            <div class="small text-muted">
                                                <?php echo e($order->created_at); ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\chia-farm.local\resources\views/orders/show.blade.php ENDPATH**/ ?>