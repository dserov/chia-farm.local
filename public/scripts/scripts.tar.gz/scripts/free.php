<?php
chdir(__DIR__);
$root=scandir("/");
foreach ($root as $folder) {
	if (strripos($folder, "plots")===0){
		$storages[$folder]=round(disk_free_space("/$folder") / 1024 / 1024 / 1024);
	}
}
$data=['tmp_free' => round(disk_free_space("/home/a/Documents/plots_tmp") / 1024 / 1024 / 1024),
'plot_free' => round(disk_free_space("/home/a/Documents/plots") / 1024 / 1024 / 1024),
'plots_count'=>count(scandir("/home/a/Documents/plots"))-2,
"storages"=>$storages];

$ip=explode(" ", exec("hostname -I"))[0];
var_dump($ip);
var_dump($data);
$authorization = "Authorization: Bearer 080042cad6356ad5dc0a720c18b53b8e53d4c274";
$url = "https://chia-farms.com/api/hosts/$ip";
$postdata = json_encode($data);
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json',"Authorization: Bearer w26Gt75jejtKyqisyBvyfNxkIbtMZqII16r6FQz8"));
#curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
$result = curl_exec($ch);
#echo curl_error($ch);
curl_close($ch);
#print_r ($result);
file_put_contents("1.txt", $result);