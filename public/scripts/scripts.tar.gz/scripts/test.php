<pre>
<?php
ini_set('error_reporting', E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
$quantity=8;
$to_ip="152.228.250.143";
$to_folder="/plots2";
$folders=scandir("/home/a/Documents/plots");
$folders_quantity=count($folders)-2;
if ($quantity <= $folders_quantity) exit;
chdir("/home/a/scripts");
$j['command']="create";
$j['task_id']=time();
$j['master_key']="b031b73e890e4f3765b840c4ddaf2402406484392bf67c9068b9c8059d3e5eb35fa515dd178034a6913c4d1276ad0ddc";
$j['farmer_key']="b1f85a48d2d0c27b66c40c4fc2ecc412544ae16e49d3543fb9d1cd9ec16d6dfe8e748f50bef399d9f6204e2a8259abce";
$j['pool_key']="83e0dc9bb0032b5c26104586583a9a4c99635e3420d00f3589609b2f15f8470050a4192013fe24eaf0198257d5290640";
$json=json_encode($j);
$task=json_decode($json);
mkdir("/home/a/Documents/plots_tmp/$task->task_id");
mkdir("/home/a/Documents/plots/$task->task_id");
exec("sh /home/a/scripts/create.sh $task->task_id $task->farmer_key $task->pool_key",$err,$err2);
$filename=scandir("/home/a/Documents/plots/$task->task_id")[2];
include('/home/a/scripts/Net/SFTP.php');

$sftp = new Net_SFTP($to_ip);
if (!$sftp->login('a', '346517')) {
    exit('Login Failed');
}
$sftp->chdir($to_folder);
chdir("/home/a/Documents/plots/$task->task_id/");
if (!$sftp->put($filename, $filename, NET_SFTP_LOCAL_FILE)) {
	file_put_contents("/home/a/scripts/error.log", json_encode($sftp->getSFTPErrors())."\r\n");
	exit;
};
function delDir($dir) {
    $files = array_diff(scandir($dir), ['.','..']);
    foreach ($files as $file) {
        (is_dir($dir.'/'.$file)) ? delDir($dir.'/'.$file) : unlink($dir.'/'.$file);
    }
    return rmdir($dir);
}
delDir("/home/a/Documents/plots_tmp/$task->task_id");
delDir("/home/a/Documents/plots/$task->task_id");
