#!/bin/bash
cd /home/a/chia-blockchain
. ./activate
chia plots create -k 32 -b 4000 -t /home/a/Documents/plots_tmp/$1 -d /home/a/Documents/plots/$1 -f $2 -p $3 >$1.log



