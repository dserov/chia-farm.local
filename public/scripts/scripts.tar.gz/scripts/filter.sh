#!/bin/sh

cat ./40.log | grep -v -P '^\t' > 401.log

curl -X POST --data-binary @401.log -H "Authorization: Bearer w26Gt75jejtKyqisyBvyfNxkIbtMZqII16r6FQz8" http://chia-farms.com/api/tasks/1
